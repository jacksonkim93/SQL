package com.prac;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class PremierLeagueTable {
	public static void main(String[] args) {
		// 팀 목록을 저장하는 리스트
		ArrayList<Team> teams = new ArrayList<>();

		// 20개의 팀을 리스트에 추가
		teams.add(new Team("첼시", 90)); // 1등으로 설정
		teams.add(new Team("맨체스터 시티", 86));
		teams.add(new Team("리버풀", 83));
		teams.add(new Team("아스날", 75));
		teams.add(new Team("토트넘", 70));
		teams.add(new Team("맨체스터 유나이티드", 68));
		teams.add(new Team("뉴캐슬 유나이티드", 66));
		teams.add(new Team("웨스트햄 유나이티드", 61));
		teams.add(new Team("에버턴", 58));
		teams.add(new Team("레스터 시티", 56));
		teams.add(new Team("리즈 유나이티드", 53));
		teams.add(new Team("울버햄프턴 원더러스", 52));
		teams.add(new Team("사우샘프턴", 50));
		teams.add(new Team("크리스탈 팰리스", 47));
		teams.add(new Team("브라이튼", 45));
		teams.add(new Team("번리", 40));
		teams.add(new Team("왓포드", 38));
		teams.add(new Team("노리치 시티", 35));
		teams.add(new Team("브렌트포드", 33));
		teams.add(new Team("애스턴 빌라", 30));

		// 승점을 기준으로 내림차순으로 정렬
		Collections.sort(teams, new Comparator<Team>() {
			@Override
			public int compare(Team t1, Team t2) {
				return t2.points - t1.points; // 내림차순 정렬
			}
		});

		// 등수표 출력
		System.out.println("Premier League Table:");
		for (int i = 0; i < teams.size(); i++) {
			System.out.println((i + 1) + ". " + teams.get(i)); // 등수와 팀 정보 출력
		}
	}

}
