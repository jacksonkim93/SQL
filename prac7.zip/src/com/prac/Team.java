package com.prac;

public class Team {
	String name; // 팀 이름
	int points; // 승점

	// 생성자
	public Team(String name, int points) {
		this.name = name;
		this.points = points;
	}

	// 팀 정보를 출력하는 메서드
	@Override
	public String toString() {
		return name + " - " + points + " points";
	}

}
