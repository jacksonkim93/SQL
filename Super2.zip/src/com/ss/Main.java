package com.ss;

import java.util.ArrayList;

import com.util.So;

public class Main {

	public static void main(String[] args) {
		Character c = new Character("고양이", 3, 100);
		Sword s = new Sword("단검", 2, 100, 50, 70);
		Sword l = new Sword("장검", 3, 150, 100, 70);

		((GameObj) c).name = "개";

		GameObj g1 = (GameObj) s;
		GameObj g2 = (GameObj) c;
		
		GameObj g3 = s;
		GameObj g4 = c;
		
		
		
		ArrayList<GameObj> gf = new ArrayList<>();
		gf.add(g3);
		gf.add(g4);
		
		Sword shortSword = (Sword) g3;
		shortSword.slash();
		
		if (g3 instanceof Sword) {
			So.ln("얘 원래 검임");
		}
		if (g4 instanceof Character) {
			So.ln("얘 원래 케릭임");
		}
		
		ArrayList<GameObj> gs = new ArrayList<>();
		gs.add(c);
		gs.add(s);
		gs.add(l);
		for (GameObj o : gs) {
			So.ln(o.name);
			if (o instanceof Sword) {
				System.out.println(o.name + "의 공격력은 " + ((Sword) o).attack);
			}
			if (o instanceof Character) {
				System.out.println(o.name + "의 체력은 " + ((Character) o).hp);
			}
		}
		int n = 1 + ((Sword) gs.get(2)).attack;
		So.ln("공격력"+n);
		
		Item z = new Sword ();
		
		Sword xxx = new Sword();
		
		Item yyy = xxx;
		
		Sword sss = (Sword) yyy;
	}
}
