package com.ss;

public class Character extends GameObj{
	
	int hp;
	
	public Character(String name, int grade, int hp) {
		super(name, grade);
		this.hp = hp;
	}
}