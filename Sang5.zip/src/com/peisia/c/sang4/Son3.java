package com.peisia.c.sang4;

public class Son3 extends Father {
	void kimchi() {
		System.out.println("피자 김치");
	}
}