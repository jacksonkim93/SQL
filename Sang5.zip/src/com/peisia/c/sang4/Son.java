package com.peisia.c.sang4;

public class Son extends Father {

	void kimchi() {
		System.out.println("치즈 김치");
	}

}