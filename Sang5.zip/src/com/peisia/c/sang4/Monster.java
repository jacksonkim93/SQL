package com.peisia.c.sang4;

public class Monster {

	int hp;
	int attack;

	void attack(Player p) {

	}
}
