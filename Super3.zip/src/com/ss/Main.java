package com.ss;

public class Main {
	
			Son son = new Son();
			son.kimchi();
		}}
