package com.prac;

public class Winner {

	String name;
	String hometown;

	public Winner(String name, String hometown) {
		this.name = name;
		this.hometown = hometown;
	}

}
