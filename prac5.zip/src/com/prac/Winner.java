package com.prac;

public class Winner {

}
