package com.prac;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		HashMap<String, Winner> winners = new HashMap<>();
		winners.put("첼시", new Winner("첼시", "런던"));
		winners.put("맨유", new Winner("맨유", "맨체스터"));
		winners.put("맨시티", new Winner("맨시티", "맨체스터"));
		winners.put("리버풀", new Winner("리버풀", "리버풀"));
		winners.put("아스날", new Winner("아스날", "런던"));
		winners.put("토트넘", new Winner("토트넘", "런던"));

		HashSet<Integer> hs = new HashSet<>();
		int r = 0;
		while (true) {
			r = (int) (Math.random() * 31 + 84);
			hs.add(r);
			if (hs.size() == 1) {
				break;
			}
		}

		Scanner sc = new Scanner(System.in);
		System.out.println("PL에서 우승할 것 같은 팀을 입력해주세요.");
		String cmd = sc.next();

		Winner selectWinner = winners.get(cmd);
		if (selectWinner != null) {
			System.out.println("선택하신 팀은 " + selectWinner.name + " 입니다.");
			System.out.println("올 해 우승은 " + r + " 승점으로 " + selectWinner.name + ", " + selectWinner.hometown + " 입니다.");

		} else {
			System.out.println("입력하신 팀은 목록에 없습니다.");
		}
		sc.close();
	}

}