package com.peisia.util;

public class Cw {
	public static void w(String s) {
		System.out.print(s);
	}

	public static void wn(String s) {
		System.out.println(s);
	}

	public static void wn() {
		System.out.println();
	}

}
