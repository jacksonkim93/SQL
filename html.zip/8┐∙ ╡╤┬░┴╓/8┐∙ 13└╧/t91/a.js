function x () {

	dateInstance = new Date();
	divNow.innerHTML = dateInstance;

	sec = sec - 1;

	if (sec <= 0) {
		divA.innerHTML = "라면 불 꺼 !";
	} else {
		divA.innerHTML = sec;

	}
}




var dateInstance;

var sec = 10;
var diva;
var divNow;
window.onload = function () {
	divA = document.getElementById("a");
	divNow = document.getElementById("now");

	dateInstance = new Date();
	divNow.innerHTML = dateInstance;

	divA.innerHTML = sec;

	setInterval(x, 1000);
}