function popupClose() {

    var popupWindow = document.getElementById("popup");
    popupWindow.style.display = "none";
}