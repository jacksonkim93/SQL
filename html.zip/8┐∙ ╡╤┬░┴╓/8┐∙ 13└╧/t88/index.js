function br(){
    document.write("<br>");
}
var now = new Date();
document.write("현재 시간은 :" + now.toLocaleTimeString()); br();