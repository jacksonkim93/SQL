function closePopup(){


    var popupWindow = document.getElementById("popup");




    popupWindow.style.color = "blue";
    popupWindow.style.height = "600px";
    popupWindow.style.width = "600px";
    popupWindow.style.background = "gray";
    popupWindow.style.transitionProperty = "width, height, background";
    popupWindow.style.transitionDuration = "2s";


}