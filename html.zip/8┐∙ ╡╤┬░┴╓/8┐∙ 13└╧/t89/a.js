var clock;

window.onload = function(){
    clock=document.getElementById("clock");
    setInterval(x, 1000);
}


function x(){
    var now = new Date();
    var result =
        now.getFullYear() + "년 "
        + now.getMonth() + "월 "
        + now.getDate() + "일 "
        + now.getHours() + "시 "
        + now.getMinutes() + "분 "
        + now.getSeconds() + "초 ";
    clock.innerHTML = result;
}