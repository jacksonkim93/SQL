function popupClose() {
    // alert("야호");
    //todo 팝업창이 닫힌것 처럼 해야됨
    var popupWindow = document.getElementById("popup");
    popupWindow.style.display = "none";

    
}