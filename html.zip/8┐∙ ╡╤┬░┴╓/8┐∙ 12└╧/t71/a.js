
var str_id = "";
var str_pw = "";
var input_id;
var input_pw;

window.onload = function () {


    input_id = document.getElementById("id");
    input_pw = document.getElementById("pw");









}

function login() {


    alert("id: " + input_id.value + " pw:" + input_pw.value);
}
