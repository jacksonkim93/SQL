function br() {
	document.write();
}

function Cat() {
	this.name = "";
	this.age = "";
	this.weight = "";
	this.family = "";
	this.color = "";

	this.crying = function () {
		document.write(this.name + "가 세상이 떠나가게 울다가");
	}

	this.eat = function (food) {
		document.write(this.name + "가" + food + " 를 먹습니다.");
	}

}

new Cat();

var kitty = new Cat();

kitty.name = " 동글이";
kitty.age = 15;
kitty.weight = " 4kg";
kitty.family = " 아비시니안";
kitty.color = " 구리색";

document.write(kitty.name); br();
document.write(kitty.age); br();
document.write(kitty.weight); br();
document.write(kitty.family); br();
document.write(kitty.color); br();

br(); br();

var yaongi = new Cat();

yaongi.name = " 카쿠";
yaongi.age = 4;
yaongi.weight = " 6kg";
yaongi.family = " 이탈리안 하운드";
yaongi.color = " 검정색";

document.write(yaongi.name); br();
document.write(yaongi.age); br();
document.write(yaongi.weight); br();
document.write(yaongi.family); br();
document.write(yaongi.color); br();

br();
br();

if (kitty.age > yaongi.age) {
	document.write(" 동글이가 형님");
} else if (kitty.age < yaongi.age) {
	document.write(" 카쿠가 형님");
} else {
	document.write(" 둘은 친구");
}

br(); br();

kitty.crying();
br(); br();

kitty.eat(" 츄르");


