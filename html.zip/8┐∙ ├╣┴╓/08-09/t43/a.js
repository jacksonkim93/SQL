function a(x){

    var c = x +33

    return c;
}

var y = a(82);

document.write(y)
