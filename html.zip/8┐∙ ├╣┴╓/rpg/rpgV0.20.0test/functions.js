function displayCharactersInfo() {
    elf.info();

    tv("\n");
}


function getReward() {
    elf.money = elf.money + orc.money;
    tv(orc.money + "원을 얻었습니다.\n");
}

function getRandomAttackValue(attack) {
    attack = attack + 1;
    var random = Math.floor(Math.random() * attack);
    return random;
}


function endBattle() {
    tv("전투 종료\n");

    elf.exp = elf.exp + orc.exp;

    tv("불쌍한 " + orc.name + "," + elf.name + "에게 경험치" + orc.exp + "을 주고 죽었습니다.\n");
    getReward();
    currentMode = "대기";
    tvGameObjectClear();
}

function procBattleTurn() {

    var monsterDamage = getRandomAttackValue(orc.attack);
    var playerDamage = getRandomAttackValue(elf.attack);

    orc.currentHp = orc.currentHp - playerDamage;
    tv(elf.name + "가 " + orc.name + "에게 데미지를 " + playerDamage + "입혔습니다.\n");
    elf.currentHp = elf.currentHp - monsterDamage;
    tv(orc.name + "가 " + elf.name + "에게 데미지를 " + monsterDamage + "입혔습니다.\n");


    if (elf.currentHp <= 0 || orc.currentHp <= 0) {
        displayCharactersInfo();
        endBattle();
        return false;
    } else {
        displayCharactersInfo();
        return true
    }
}

function turn() {
    if (currentMode == "전투") {
        procBattleTurn();
    } else {
        procNormalTurn();
    }
    turnCount++;
    itTurn.value = turnCount;
    console.log("현재 턴:" + turnCount);
}

function procNormalTurn() {


    tv("특별한 것은 보이지 않는다.\n");
}

function screenMessageBoxScrollToBot() {
    screenMessageBox.scrollTop = screenMessageBox.scrollHeight;
}

function move(direction) {
    var nowRoom = getCurrentRoomObject()
    var connectionRoomId = nowRoom.getIdByDirection(direction);
    if (connectionRoomId == 0) {
        tv("갈 수 없음\n");
        return;
    } else {
        currentRoomId = connectionRoomId;
        console.log("현재 방번호:" + currentRoonId);
    }

    switch (direction) {
        case "동":
            tv("동쪽으로 이동했습니다.\n");
            break;
        case "서":
            tv("서쪽으로 이동했습니다.\n");
            break;
        case "남":
            tv("남쪽으로 이동했습니다.\n");
            break;
        case "북":
            tv("북쪽으로 이동했습니다.\n");
            break;
        case "위":
            tv("위쪽으로 이동했습니다.\n");
            break;
        case "밑":
            tv("아래쪽으로 이동했습니다.\n");
            break;
    }

    displayRoomInfo();
    turn();
}


function getCurrentRoomObject() {
    for (var i = 0; i < roomArray.length; i++) {
        if (roomArray[i].id == currentRoomId) {
            return roomArray[i];
        }
    }
}

function displayRoomInfo() {
    getCurrentRoomObject().displayRoomInfo();
    displayCurrentRoomMonstersInfo();
}

function displayCurrentRoomMonstersInfo() {

    var currentRoomMonstersArray = getCurrentRoomMonsters();
    var monstersString = "";
    for (var i = 0; i < currentRoomMonstersArray.length; i++) {
        console.log(currentRoomMonstersArray[i].name);

        monstersString = monstersString + currentRoomMonstersArray[i].getInfo();
    }
    tvGameObject(monstersString);
}

function getCurrentRoomMonsters() {
    var currentRoomMonsters = new Array(); {

        for (var i = 0; i < monsterArray.length; i++) {
            currentRoomMonsters.push(monsterArray[i]);
        }
    }
    return currentRoomMonsters;
}