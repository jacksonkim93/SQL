function Character(name,hp,attack){

    this.name = name;
    this.currentHp = hp;
    this.maxHp = hp;
    this.attack = attack;
    this.exp = 0;
    this.money = 0;

    this.info - function(){

        tvPlayerInfo("["+this.name+"("+this.currentHp + "/" + this.maxHp+")](exp: " +this.exp+"/300)");
    }
}