




function tv(str){
    var screenString = ScreenMessageBox.value
    screenString = screenString + str;
    ScreenMessageBox.value = screenString;

    ScreenMessageBoxScrollToBot();
}

function tvClear(){
    ScreenMessageBox.value = "";
}
function tvPlayerInfo(str){
    var screenString = screenPlayerInfo.value;
    screenPlayerInfo.value = str;
}

function tvPlayerInfoClear(){
    screenPlayerInfo.value = "";
}
function tvGameObject(str){
    var screenString = ScreenGameObject.value;
    ScreenGameObject.value = str;
}

function tvGameObjectClear(){
    ScreenGameObject.value = "";
}

function br(){
    document.write("<br>");
}
function hr(){
    document.write("<hr>")
}