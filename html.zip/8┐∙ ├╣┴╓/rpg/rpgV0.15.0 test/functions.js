function displayCharactersInfo(){
    elf.info();
    orc.info();
    tv("\n");
}


function getReward() {
    elf.money = elf.money + orc.money;
    tv(orc.money + "원을 얻었습니다.\n");
}

function getRandomAttackValue(attack) {
    attack = attack + 1;
    var random = Math.floor(Math.random() * attack);
    return random;
}


function endBattle() {
    tv("전투종료\n");

    elf.exp = elf.exp + orc.exp;

    tv("불쌍한 " + orc.name + ", " + elf.name + "에게 경험치" + orc.exp + "을 주고 죽었습니다.\n");
    getReward ();
    currentMode = "대기";
    tvGameObjectClear();
}

function procBattleTurn(){

    var monsterDamage = getRandomAttackValue(orc.attack);
    var plyerDamage = getRandomAttackValue(elf.attack);

    orc.currentHp = orc.currentHp - playerDamage;
    tv(elf.name + "가 " + orc.name + "에게 데미지를 " + playerDamage + " 입혔습니다\n");
    elf.currentHp = elf.currentHp - monsterDamage;
    tv(orc.name + "가 " + elf.name + "에게 데미지를 " + monsterDamage + " 입혔습니다\n");


    if (elf.currentHp <= 0 || orc.currentHp <= 0) {
        displayCharactersInfo();
        endBattle();
        return false;
    } else {
        displayCharactersInfo();
        return true;
    }
}

function turn(){
    if(currentMode == "전투"){
        procBattleTurn();
    } else {
        procNormalTurn();
    }
    turnCount++;
    itTurn.value = turnCount;
    console.log("현재 턴:"+turnCount);
}

function procNormalTurn(){


    
    tv("특별한 것은 보이지 않는다.\n");
}

function screenMessageBoxScrollToBot(){

    screenMessageBox.scrollTop = screenMessageBox.scrollHeight;
}

function moveEast(){
    tv("동쪽으로 이동했습니다.");
    turn();
}
function moveWast(){
    tv("서쪽으로 이동했습니다.");
    turn();
}
function moveSouth(){
    tv("남쪽으로 이동했습니다.");
    turn();
}
function moveNorth(){
    tv("북쪽으로 이동했습니다.");
    turn();
}
function moveUp(){
    tv("위쪽으로 이동했습니다.");
    turn();
}
function moveDown(){
    tv("밑쪽으로 이동했습니다.");
    turn();
}
