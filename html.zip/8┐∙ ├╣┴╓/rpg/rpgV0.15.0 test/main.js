var screenMessageBox;
var screenGameObject;
var screenPlayerInfo;
var orc = new Monster("오크전사", 100, 10);
var elf = new Character("엠피스", 200, 30);
var turnCount = 1;
var itTurn;
var currentMode = "대기";

window.onload = function (){
    screenMessageBox = document.getElementById("screen_message_box");
    screenGameObject = document.getElementById("screen_game_object");
    screenPlayerInfo = document.getElementById("screen_player_info");
    itTurn = document.getElementById("input_txt_turn");

    displayCharactersInfo();
}

