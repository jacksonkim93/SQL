function tv(str){
    var screenString = screenMessageBox.value;
    screenString = screenString + str;
    screenMessageBox.value = screenString;

    screenMessageBoxScrollToBot();
}

function tvClear(){
    screenMessageBox.value = "";
}
function tvPlayerInfo(str){
    var screenString = screenPlayerInfo.value;
    screenPlayerInfo.value = str;
}
function tvPlayerInfoClear(){
    screenPlayerInfo.value = "";
}
function tvGameObject(str){
    var screenString = screenGameObject.value;
    screenGameObject.value = str;
}
function tvGameObjectClear(){
    screenGameObject.value = "";
}
function br(){
    document.write("<br>");
}
function hr(){
    document.write("<hr>");
}