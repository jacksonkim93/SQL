function Monster(){
	this.name;
	this.hp;
	this.attack;

	this.info = function(){
		hr();
		dw("["+this.name+"]["+this.hp+"][atk:"+this.attack+"]");
		hr();
	}
}

function Character(){
	this.name;
	this.hp;
	this.attack;

	this.info = function(){
		hr();
		dw("["+this.name+"]["+this.hp+"][atk:"+this.attack+"]");
		hr();
	}
}

var orc = new Monster();
var elf = new Character();

orc.name = "오크전사";
orc.hp = 100;
orc.attack = 20;

elf.name = "엠피스";
elf.hp = 200;
elf.attack = 20;

orc.info();
elf.info();