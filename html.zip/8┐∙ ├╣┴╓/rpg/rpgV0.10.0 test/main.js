function displayCharactersInfo(){
    elf.info();
    orc.info();
    tv("\n");
}


function getReward() {
    elf.money = elf.money + orc.money;

    tv(orc.money + "원을 얻었습니다.\n");
}

function getRandomAttackValue(attack) {
    attack = attack + 1;
    var random = Math.floor(Math.random() * attack);
    return random;
}


function endBattle() {

    tv("전투종료\n");


    elf.exp = elf.exp + orc.exp;


    tv("불쌍한 " + orc.name + ", " + elf.name + "에게 경험치 " + orc.exp + "을 주고 죽었습니다.\n");

    getReward();

}

function procBattleTurn(){

    var monsterDamage = getRandomAttackValue(orc.attack);
    var playerDamage = getRandomAttackValue(elf.attack);

    orc.currentHp = orc.currentHp = playerDamage;

    tv(elf.name + "가 " + orc.name + "에게 데미지를 " + playerDamage + "입혔습니다.\n");
    elf.currentHp = elf.currentHp = playerDamage;

    tv(orc.name + "가 " + elf.name + "에게 데미지를 " + monsterDamage + "입혔습니다.\n");




    if (elf.currentHp <= 0 || orc.currentHp <= 0) {
        endBattle();
        displayCharactersInfo();
        return false;
    } else {
        displayCharactersInfo();
        return true;
    }
}




var screenMessageBox;
var screenGameObject;
var screenPlayerInfo;
var orc = new Monster("오크전사", 100, 10);
var elf = new Character("엠피스", 200, 30);

window.onload = function () {
    screenMessageBox = document.getElementById("screen_message_box");
    screenGameObject = document.getElementById("screen_game_object");
    screenPlayerInfo = document.getElementById("screen_player_info");

    displayCharactersInfo();



    tv("전투 시작\n");


    var loop = true;
    while (loop) {
        loop = procBattleTurn();
    }
}

