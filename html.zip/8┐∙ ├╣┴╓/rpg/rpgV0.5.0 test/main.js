var orc = new Monster("오크전사",100,10);
var elf = new Character("엠피스",200,30);

displayCharactersInfo();

hr();
dw("전투 시작")
hr();

var monsterDamage = getRandomAttackValue(orc.attack);
dw(elf.name + "가 " + orc.name + "에게 데미지를 "+playerDamage +" 입혔습니다.<br>");
dw(orc.name + "가 " + elf.name + "에게 데미지를 "+monsterDamage +" 입혔습니다.<br>");


displayCharactersInfo();

function getRandomAttackValue(attack){
    attack = attack + 1;
    var random = Math.floor(Math.random()*attack);
    return random;
}

function displayCharactersInfo(){
    hr();
    elf.info();
    orc.info();
    hr();
}