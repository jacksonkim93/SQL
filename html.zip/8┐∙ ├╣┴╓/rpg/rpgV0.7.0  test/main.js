var orc = new Monster("오크전사",100,10);
var elf = new Character("엠피스",200,10);

displayCharactersInfo();

hr();
dw("전투시작");
hr();

var loop = true;
while(loop){
    loop = procBattleTurn();
}

function procBattleTurn(){
    var monsterDamage = getRandomAttackValue(orc.attack);
    var playerDamage = getRandomAttackValue(elf.attack);

    orc.currentHp = orc.currentHp - playerDamage;
    dw(elf.name + "가 " + orc.name + "에게 데미지를 " +playerDamage +" 입혔습니다.<br>")
    elf.currentHp = elf.currentHp - monsterDamage;
    dw(orc.name + "가 " + elf.name + "에게 데미지를 " +monsterDamage +" 입혔습니다.<br>")


    if(elf.currentHp <= 0 || orc.currentHp <= 0){
        endBattle();
        displayCharactersInfo();
        return false;
    } else {
        displayCharactersInfo();
        return true;
    }
}

function getRandomAttackValue(attack){
    attack = attack + 1;
    var random = Math.floor(Math.random()*attack);
    return random;
}

function endBattle(){
    dw("전투종료");
    br();
    elf.exp = elf.exp + orc.exp;
}

function displayCharactersInfo(){
    hr();
    elf.info();
    orc.info();
    hr();
}