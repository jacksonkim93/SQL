function dw(str){
    var screenString = screen.value;
    screenString = screenString + str;
    screen.value = screenString;
}
function br(){
    document.write("<br>");
}
function hr(){
    document.write("<hr>");
}