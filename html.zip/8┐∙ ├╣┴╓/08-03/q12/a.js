var s=prompt("값 입력해")
if (s>100){
    alert("100보다 커")
}
else {
    alert("100보다 작아")
}