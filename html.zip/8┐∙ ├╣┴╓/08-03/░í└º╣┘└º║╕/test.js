var s = Object.freeze({SCISSORS: 1, ROCK: 2, PAPER: 3});
dw(s.ROCK);