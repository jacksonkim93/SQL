var a=100
if (a>1){
    alert("크다")
}