var s=prompt ("값을 입력해")
switch(s){
    case"1":
    alert ("1임")
    break;
    case"2":
    alert ("2임")
    break;
    case"3":
    alert ("3임")
    break;
    default:
    alert ("1,2,3 아님")
    break;
    
}