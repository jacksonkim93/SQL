var s=prompt("값 입력해")
if (s>100){
    alert("100보다 큼")
}
else if (s<100){
    alert("100보다 작음")
}
else [
    alert("100임")
]