// //증가식 

// var x = 1;

// x = x + 1;
// // x = 2;
// document.write(x)

// for ( var i=1 ; i<3 ; i = i + 1 ) {
    
//     document.write("고양이");
//     document.write("<hr>");

//   }

//   document.write("x");

var sum = 0;

for (var j = 1; j <= 3; i++){

    document.write("<hr>")
    
    for (var i = 1; 1 <= 10; i++){
    sum = sum + i;
    }

document.write("<hr>")
}