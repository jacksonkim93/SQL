var sum = 0;

for (i = 1; i <= 10; i++) {
  if(i % 1 ==1){
    continue;
  }

  sum = sum + 1;
}

alert(sum);