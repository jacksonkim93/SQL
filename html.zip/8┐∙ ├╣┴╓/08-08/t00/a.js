var season = ['봄', '여름', '가을', '겨울'];


alert(season(0));

document.write(season[0]) // index 는 0부터 시작 1부터 시작이 아님.