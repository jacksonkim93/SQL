package com.prac;

import java.util.HashMap;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
//		int a; // 리터럴
//		long b = 2147836478L;
//
//		a = (int) b;
//		System.out.println(a);
//	}
// ------------------------------------------
//		float a = 1.5f;
//
//		double b = 1.5;
//
//		a = (float) b;
//		System.out.println(a);

// --------------------------------------------
//	Object o; // 모든 클래스의 최고의 조상
//		Cat cat = new Cat();
//		System.out.println((Object)cat);
//		
//		Sword s = new Sword();
//		GameObj g = s;

// ------------------------------------------------

		// 이것이자바다 p.534
//		Date now = new Date();
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyy년 MM월 dd일 hh시 mm분 ss초");
//
//		String strNow = sdf.format(now);
//
//		System.out.println(strNow);
//
//		System.out.println(now);

		// import java.util.Date;
// -------------------------------------------------------------------------
//		Calendar n = Calendar.getInstance();
//		int year = n.get(Calendar.YEAR);
//		int month = n.get(Calendar.MONTH) + 1;
//		int day = n.get(Calendar.DAY_OF_MONTH);
//		int week = n.get(Calendar.DAY_OF_WEEK);
//		String strWeek = null;
//		switch (week) {
//		case Calendar.MONDAY:
//			strWeek = "월";
//			break;
//		case Calendar.TUESDAY:
//			strWeek = "화";
//			break;
//		case Calendar.WEDNESDAY:
//			strWeek = "수";
//			break;
//		case Calendar.THURSDAY:
//			strWeek = "목";
//			break;
//		case Calendar.FRIDAY:
//			strWeek = "금";
//			break;
//		case Calendar.SATURDAY:
//			strWeek = "토";
//			break;
//		default:
//			strWeek = "일";
//		}
//
//		int amPm = n.get(Calendar.AM_PM);
//		String strAmPm = null;
//		if (amPm == Calendar.AM) {
//			strAmPm = "오전";
//		} else {
//			strAmPm = "오후";
//		}
//
//		int hour = n.get(Calendar.HOUR);
//		int minute = n.get(Calendar.MINUTE);
//		int second = n.get(Calendar.SECOND);
//
//		System.out.print(year + "년 ");
//		System.out.print(month + "월 ");
//		System.out.print(day + "일 ");
//		System.out.print(strWeek + "요일 ");
//		System.out.print(strAmPm + " ");
//		System.out.print(hour + "시 ");
//		System.out.print(minute + "분 ");
//		System.out.print(second + "초 ");
//
//		-------------------------------------------------------

//		Dog dog = Dog.getInstance();// 프로그램을 다를때 이 객체는 하나만 있게 만들 수 있음
//----------------------------------------------------------------

//		HashMap<String, String> a = new HashMap<>();
//		a.put("CODE111", "고양이");
//		a.put("CODE222", "강아지");
//
//		String r = a.get("CODE222");
//		System.out.println(r);
// ------------------------------------------------------
//		HashSet<Integer> hs = new HashSet<>();
//		int r = 0;
//		while (true) {
//			r = (int) (Math.random() * 45 + 1);
//			hs.add(r);
//			if (hs.size() == 6) {
//				break;
//			}
//		}
//		Iterator<Integer> it = hs.iterator();
//		System.out.println("while, next() 으로 꺼내기");
//		while (it.hasNext()) {
//			int s = it.next();
//			System.out.println(s + " ");
//		}
// -----------------------------------------------------------
//		HashMap<String, Food> foods = new HashMap<>();
//
//		Food f1 = new Food("라면", true, 3500);
//		Food f2 = new Food("냉면", false, 12000);
//		
//
//		foods.put("라면", f1);
//		foods.put("냉면", f2);
//
//		Scanner sc = new Scanner(System.in);
//		System.out.println("원하는 음식 이름을 입력해주세요");
//		String cmd = sc.next();
//
//		Food selectFood = foods.get(cmd);
//		System.out.println("주문하신 음식은 " + selectFood.name);
//		System.out.println("hot/cold 는: " + selectFood.ishot);
//		System.out.println("가격은 :" + selectFood.price);

		// 음식 리스트를 등록
		// 음식을 검색
		HashMap<String, Food> foods = new HashMap<>();

		foods.put("라면", new Food("라면", true, 3500));
		foods.put("냉면", new Food("냉면", false, 12000));
		foods.put("쫄면", new Food("쫄면", false, 12000));
		foods.put("짜장면", new Food("짜장면", true, 10000));
		foods.put("파스타", new Food("파스타", true, 15000));

		Scanner sc = new Scanner(System.in);
		System.out.print("원하시는 음식 이름을 입력해주세요:");
		String cmd = sc.next();

		Food selectFood = foods.get(cmd);
		System.out.println("주문하신 음식은:" + selectFood.name);
		System.out.println("가격은 :" + selectFood.price + "원 입니다 카드로 결제하시겠습니까?");
	}
}
