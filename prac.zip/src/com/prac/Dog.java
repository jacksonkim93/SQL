package com.prac;

public class Dog {

	private static Dog xx = new Dog();

	private Dog() {

	}

	static Dog getInstance() {
		return xx;
	}
}
