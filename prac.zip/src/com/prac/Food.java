package com.prac;

import java.security.KeyStore.Entry.Attribute;
import java.util.HashMap;

public class Food {
	String name;
	boolean ishot;
	int price;

	HashMap<String, Attribute> attrubute = new HashMap<>();

	public Food(String name, boolean ishot, int price) {

		this.name = name;
		this.ishot = ishot;
		this.price = price;
	}

}
