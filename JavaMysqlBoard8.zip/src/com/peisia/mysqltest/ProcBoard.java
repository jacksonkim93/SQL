package com.peisia.mysqltest;

import com.peisia.c.board.display.Disp;
import com.peisia.util.Ci;
import com.peisia.util.Cw;
import com.peisia.util.Db;

public class ProcBoard {
	void run() {
		Disp.title();
		Db.dbInit();
		Db.getPostCount();
		loop: while (true) {
			Db.dbPostCount();
			Disp.menuMain();
			String cmd = Ci.r("명력입력");
			switch (cmd) {
			case "1":
				ProcList.run();
				break;
			case "2":
				ProcRead.run();
				break;
			case "3":
				ProcWrite.run();
				break;
			case "4":
				ProcDel.run();
				break;
			case "5":
				ProcEdit.run();
				break;
			case "6":
				ProcList.search();
				break;
			case "0":
				break;
			case "e":
				Cw.wn("프로그램 종료");
				break loop;
			}
		}
	}
}