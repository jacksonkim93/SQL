package com.peisia.mysqltest;

import com.peisia.util.Ci;
import com.peisia.util.Cw;
import com.peisia.util.Db;

public class ProcRead {
	static public void run() {
		String readNo = Ci.r("읽을 글 번호를 입력해주세요:");
		try {
			Db.result = Db.st.executeQuery("select * from board where b_no=" + readNo);
			Db.result.next();
			String title = Db.result.getString("b_title");
			String content = Db.result.getString("b_text");
			Cw.wn("글제목:" + title);
			Cw.wn("글내용:" + content);
			ProcReply.list(Integer.parseInt(readNo));
			loop: while (true) {
				String cmd = Ci.r("명령[x:나가기,r:댓글쓰기]");
				switch (cmd) {
				case "x":
					break loop;
				case "r":
					ProcReply.write(Integer.parseInt(readNo));
					break;
				default:
					Cw.wn("장난x");
				}
			}

		} catch (Exception e) {

		}
	}
}