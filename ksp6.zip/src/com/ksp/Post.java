package com.ksp;

public class Post {

}