package com.ksp;

public class Board {

}
