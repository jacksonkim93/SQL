package com.rpgq1;

public class Main {

	public static void main(String[] args) {
		
		Character player = new Character("���ǽ�", 100, 20, "����");
		
		player.info();
	}
}