package com.rpgq1;

public class Character {

	String name;
	int hp;
	int attack;
	String race;
	
	Character(String name, int hp, int attack, String race) {
		
		
		
		
		
		this.name = name;
		this.hp = hp;
		this.attack = attack;
		this.race = race;
		System.out.println(this.name + "��(��) �¾");
	}
	
	
	void info() {
		System.out.println("�̸�:" + this.name + "[" + this.hp + "]" + " ���ݷ�:" + this.attack);
	}
}