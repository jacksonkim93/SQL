package com.catq;

public class Main {

	public static void main(String[] args) {
		Cat kitty = new Cat(10, "ŰƼ", "�Ļ�����");
		
		Cat yaongi = new Cat();
		yaongi.age = 10;
		
		Cat norangi = new Cat(100, "�����");
		
		int sum = norangi.add(0, 2);
		System.out.println(sum);
	}
}