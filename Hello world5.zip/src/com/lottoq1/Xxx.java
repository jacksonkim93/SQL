package com.lottoq1;

import com.lotto1.Lotto;

public class Xxx {
	
	public static void main(String[] args) {
		Lotto lotto = new Lotto();
		lotto.run();
	}
	
}
