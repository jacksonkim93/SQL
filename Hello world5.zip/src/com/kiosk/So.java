package com.kiosk;

public class So {
	static public void p(String s) {
		System.out.print(s);
	}

	static public void ln(String s) {
		System.out.println(s);
	}
}
