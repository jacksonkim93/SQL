package com.chelsea.helloworld5;

public class Helloworld6 {
	public static void main(String[] args) {
		System.out.println("hello world6");
	}

}

