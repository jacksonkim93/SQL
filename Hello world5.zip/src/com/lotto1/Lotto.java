package com.lotto1;

public class Lotto {

	public void run() {
//			int x[] = {1,2};
		// �ζ� ����
		int p[] = { 1, 2, 3, 4, 5, 6 };
		int r[] = new int[6];

		r[0] = (int) (Math.random() * 45 + 1);

		// �ߺ�üũ: 2��°��ȣ
		while (true) {
			r[1] = (int) (Math.random() * 45 + 1);
			if (r[0] != r[1]) {
				break;
			}
		}

		// �ߺ�üũ: 3��°��ȣ
		while (true) {
			r[2] = (int) (Math.random() * 45 + 1);
			if (r[0] != r[2] && r[1] != r[2]) {
				break;
			}
		}
		while (true) {
			r[3] = (int) (Math.random() * 45 + 1);
			if (r[3] != r[0] && r[3] != r[1] && r[3] != r[2]) {
				break;
			}
		}
		while (true) {
			r[4] = (int) (Math.random() * 45 + 1);
			if (r[4] != r[0] && r[4] != r[1] && r[4] != r[2] && r[4] != r[3]) {
				break;
			}
		}
		while (true) {
			r[5] = (int) (Math.random() * 45 + 1);
			if (r[5] != r[0] && r[5] != r[1] && r[5] != r[2] && r[5] != r[3] && r[5] != r[4]) {
				break;
			}
		}

		System.out.println("=== ��÷ ��ȣ ===");
		System.out.print(r[0] + " ");
		System.out.print(r[1] + " ");
		System.out.print(r[2] + " ");
		System.out.print(r[3] + " ");
		System.out.print(r[4] + " ");
		System.out.print(r[5] + " ");

		int win = 0;
		for (int i = 0; i < 6; i = i + 1) {
			for (int j = 0; j < 6; j = j + 1) {
				if (p[i] == r[j]) {
					win = win + 1;
				}
			}
		}

		System.out.println("���᰹��:" + win);
	}
}
