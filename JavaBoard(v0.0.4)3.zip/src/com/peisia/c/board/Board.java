package com.peisia.c.board;

import com.peisia.c.board.data.Data;
import com.peisia.c.board.display.Disp;

public class Board {
	public static final String VERSION = "v0.0.10";
	public static final String TITLE = "김선경 게시판 (" + VERSION + ")feat sk.kim";

	public void run() {
		Data.loadData();
		Disp.title();
		ProcMenu.run();
	}

}
