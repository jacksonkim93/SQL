package com.peisia.c.board.data;

import java.util.ArrayList;

public class Data {
	static public ArrayList<Post> posts;

	static public void loadData() {
		posts = new ArrayList<>();
	}

}
