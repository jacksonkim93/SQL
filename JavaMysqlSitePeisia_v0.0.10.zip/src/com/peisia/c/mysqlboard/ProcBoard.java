package com.peisia.c.mysqlboard;

import com.peisia.c.mysqlboard.display.DispBoard;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;
import com.peisia.c.util.Db;

public class ProcBoard {
	static public void run() {
		DispBoard.title();
		Db.getPostCount();
		loop: while (true) {
			Db.dbPostCount();
			DispBoard.menuMain();
			String cmd = Ci.r("명령 입력");
			switch (cmd) {
			case "1":
				ProcList.run();
				break;
			case "2":
				ProcRead.run();
				break;
			case "3":
				ProcWrite.run();
				break;
			case "4":
				ProcDel.run();
				break;
			case "5":
				ProcEdit.run();
				break;
			case "6":
				ProcList.search();
				break;
			case "x":
				Cw.wn("사이트 메인으로 이동");
				break loop;
			}
		}
	}
}