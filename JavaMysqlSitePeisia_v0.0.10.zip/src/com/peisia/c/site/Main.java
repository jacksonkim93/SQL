package com.peisia.c.site;

public class Main {
	public static void main(String[] args) {
		SiteMain.run();
	}
}