/**
 * 
 */
/**
 * @author hoyangi
 *
 */
module JavaMysqlTest {
	requires java.sql;
}